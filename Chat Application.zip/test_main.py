# from flask import Flask, url_for

# app = Flask(__name__)

# with app.test_client() as c:
#     response = c.get('/some/path/that/exists')
#     self.assertEquals(response.status_code, 200)